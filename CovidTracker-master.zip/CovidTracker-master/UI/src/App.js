/* eslint-disable react/jsx-no-target-blank */

import React, { Component } from 'react';
import {BrowserRouter as Router, Route, Link } from '../node_modules/react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css"
import ListSocialInteraction from './components/ListSocialInteraction';
import ListVisitedPlace from './components/ListVisitedPlace';
import logo from "./image/logo.png";
import Home from './components/home';

export default class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
          <nav className="navbar navbar-expand-sm navbar-light bg-light">
            <a className="navbar-brand" href="https://www.codeproject.com/Articles/Al-Moje" target="_blank">
              <img src={logo} width="24" height="24" alt="CodingTheSmartway.com" />
            </a>         
          <Link to="/" className="navbar-brand"></Link>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav mr-auto">
            <li className="navbar-item">
                <Link to="/Home" className="nav-link">Home</Link>
              </li>
              <li className="navbar-item mr-2">
                <Link to="/ListSocialInteraction" className="nav-link">Social Interaction</Link>
              </li>                         
              <li className="navbar-item mr-2">
                <Link to="/ListVisitedPlace" className="nav-link">Place Exposure</Link>
              </li>          
            </ul>      
          </div>        
          </nav>   
          <Route exact path="/" component={Home} /> 
          <Route exact path="/Home" component={Home} />     
          <Route exact path="/ListSocialInteraction" component={ListSocialInteraction} />
          <Route exact path="/ListVisitedPlace"component={ListVisitedPlace}/>
        </div>
       </Router>  
    );
  }
}

