function GraphMonth(d) {
    let monRet = "";
    //let mYr = d.toString().split("T")[0].split("-")[0]
    let mMon = d.toString().split("T")[0].split("-")[1]
    let mDay = d.toString().split("T")[0].split("-")[2]  
    switch (mMon) {
        case '01':
         monRet ="Jan" ; 
         break;
         case '02':
         monRet ="Feb" ; 
         break;
         case '03':
         monRet ="Mar";  
         break;
         case '04':
         monRet ="Apr";  
         break;
         case '05':
         monRet ="May";  
         break;
         case '06':
         monRet ="Jun";  
         break;
         case '07':
         monRet ="Jul";  
         break;
         case '08':
         monRet ="Aug"  
         break;
         case '09':
         monRet ="Sep"  
         break;
         case '10':
         monRet ="Oct"  
         break;
         case '11':
         monRet ="Nov"  
         break;
         case '12':
         monRet ="Dec"  
         break;
    
        default:
            break;
    }        
    //let mReturn = monRet + " " + mDay + ", " + mYr;   
    let mReturn = monRet + " " + mDay     
    return mReturn;
}
export default GraphMonth
