import React from "react";
import {TableRow,TableCell} from "@material-ui/core";
function VisitedTableHeader() {
   return ( 
    <TableRow style={{ background: '#f2e6ff' }}>
      <TableCell >Place</TableCell>
      <TableCell >Date</TableCell>
      <TableCell >Hours</TableCell>
      <TableCell >Is Crowded?</TableCell>
      <TableCell ></TableCell>
      <TableCell ></TableCell>
    </TableRow>
  );
}
export default VisitedTableHeader;


