import React, { Component } from 'react';
import ChartVisited from './chartVisited';
import ChartInteractions from './chartInterAction';
import NotificationSystem from './notificationSystem'
import NotificationSystem2 from './notoficationSystem2'

export default class home extends Component {
    constructor(props){
        super(props);
          this.state = {
            toastNotifStatus: this.props.toastNotifStatus
          }
    }
      
    render() {

        return (
            
            <div>              
                <h3>COVID Exposure Tracker Tools</h3>    
                <div className="notification-component-wrapper">
                    <NotificationSystem ref="notificationSystem"/>
                </div>          
                <div style={{ background: '#f2e6ff' }}>
                    <ChartVisited  Height="100%"/>
                </div>
                <br/>
                <br/>
                <h3>COVID Exposure Tracker Tools</h3>
                <div className="notification-component-wrapper">
                    <NotificationSystem2 ref="notificationSystem"/>
                </div>   
                <div style={{ background: '#f4e6ff' }}>
                    <ChartInteractions  width="50%"/>
                </div> 
            </div>
            
        )
    }
}
