import React, { Component } from 'react'
import {Bar} from 'react-chartjs-2'
import axios from 'axios';
import GraphMonth from '../components/GraphMonth'
require("react-bootstrap/ModalHeader");
const  apiUrl =  "http://localhost:5000/api/"


class chartVisited extends Component {
    
    constructor(props) {
        super(props);  
        this.state = { Data: {} }; 
    }

    componentDidMount() {  
        axios.get(apiUrl + 'visited-places')  
        .then(res => {  
                console.log(res);  
                const ipl = res.data;  

                let dateVisited = [];
                let sumHours = [];  
                
                ipl.forEach(record => {  
                        dateVisited.push(GraphMonth(record.date))
                        sumHours.push(record.hours);  
                });  
                this.setState({  
                        Data: {  
                                labels:dateVisited,  
                                datasets: [  
                                        {  
                                                label: 'Recent visited places',  
                                                data: sumHours,  
                                                backgroundColor: [  
                                                    "#3cb371",
                                                    "#0000FF", 
                                                    "#9966FF",
                                                    "#4C4CFF", 
                                                    "#00FFFF",
                                                    "#f990a7",
                                                    "#aad2ed",  
                                                    "#FF00FF",
                                                    "Blue",
                                                    "Red"        
                                                ]  
                                        }  
                                ]  
                        }  
                });  
        })  
        
    }  
    render() {         
        return (  
            <div>  
                <Bar  
                    data={this.state.Data}  
                    options={{ maintainAspectRatio: false }} 
                />  
            </div>  
        )  
    }
}
export default chartVisited
