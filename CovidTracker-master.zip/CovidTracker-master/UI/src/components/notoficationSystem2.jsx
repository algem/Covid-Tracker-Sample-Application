import React, { Component } from 'react';

let  vMessage1 = "You did not practice social distancing for the last 14 days..\r\nStay at home and maintain 1-2 meters away from other people."
let namesSplit1 = vMessage1.split(/\r?\n/);
//let  vMessage2 = "You are maintaining proper social distancing.  Keep it up!"
//let namesSplit2 = vMessage1.split(/\r?\n/);



//const noti = 'You have bee exposed to a crowded place for the last 14 days..'+
//'<br/>Try to avoid crowded places to minimised your exposure risk.'
class NotificationSystem2 extends Component {
    
    render() {
        return (
            <>
               {namesSplit1}
            </>
           
        )
    }
}
export default NotificationSystem2 