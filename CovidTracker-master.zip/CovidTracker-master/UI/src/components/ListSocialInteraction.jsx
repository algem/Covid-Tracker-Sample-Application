import React, { Component } from 'react';
import SICounters from './SICounters'
import '../App.css';
import axios from 'axios';
import Swal from 'sweetalert2';
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import SIVisitedTableHeader from './SIVisitedTableHeader';
import {TableHead,TableBody} from "@material-ui/core";

require("react-bootstrap/ModalHeader");
const  apiUrl =  "http://localhost:5000/api/"

class ListSocialInteraction extends Component{ 
  constructor(props) {
    super(props)
    this.onHandleDateChange = this.onHandleDateChange.bind(this); 
    this.onHandleNumberChange = this.onHandleNumberChange.bind(this); 
    this.handleChangeChk2 = this.handleChangeChk2.bind(this); 
    this.handleChangeChk = this.handleChangeChk.bind(this); 
    console.log(this.props)
  }
  state = {counters:[],record:[],body:[],action:'',modalAddEdit:false,checked:true,   
  wasFiltered: 'false',regexpDate : /^[0-9\b/]+$/,regexpNumber : /^[0-9\b]+$/,
    _id:'',
    name: '',
    date: '', 
    hours: '', 
    isSocialDistancing: 'false',
    __v:"0",    
  }

  componentDidMount() {
    axios.get(apiUrl + 'social-interactions')
      .then(res => {       
       this.setState({counters: res.data});  
       this.setState({_id: this.state.counters._id}); 
       this.setState({name: this.state.counters.name}); 
       this.setState({date: this.state.counters.date});    
       this.setState({hours: this.state.counters.hours});  
       this.setState({isSocialDistancing: this.state.counters.isSocialDistancing}); 
      })    
  }

  handleChangeChk=e=>{
    let result = this.state.wasFiltered === 'false' || this.state.wasFiltered === '' ? 'true':'false'
    if (result === "true") {     
      let today = new Date();
      //alert( new Date(today.setDate(today.getDate()-14)));
      let min   = Date.parse(new Date(today.setDate(today.getDate()-14)));
      let max   = Date.parse(new Date());
      this.filteredData = this.state.counters.filter((c => Date.parse(new Date(c.date)) >= min && Date.parse(new Date(c.date)) <= max));
      this.setState({counters: this.filteredData});  
      this.setState({filteredData:[]});  
      this.setState({wasFiltered: result})
    }else {
      this.componentDidMount();
      this.setState({wasFiltered: result})    
    }
  }

  onHandleDateChange = e => {
    let date = e.target.value;
    if (date === '' || this.state.regexpDate.test(date)) {
        this.setState({ [e.target.name]: date })
        return true;
    }     
  };

  onHandleNumberChange = e => {  
    let hours = e.target.value;
    if (hours === '' || this.state.regexpDate.test(hours)) {
        this.setState({ [e.target.name]: hours })
        return true;
    }     
  };

  handleDelete = (counterId)=>{
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it',
      }).then((result) => {
        if (result.isConfirmed) {       
          const urlPath = apiUrl + 'social-interactions/' + counterId
            axios.delete(urlPath, { params: { _id: counterId } }).then(response => {
            console.log(response);
            const counters = this.state.counters.filter(c => c._id !== counterId);
            this.setState({counters});
          });
        } else if (result.isDismissed) {
          return;
        }
      })
  };

  handleAdd = (id) =>{
    this.setState({ modalAddEdit: true });
    let todayDate = new Date();
    let today = (todayDate.getMonth() + 1) + "/"+ todayDate.getDate() + "/" + todayDate.getFullYear() 
    this.action = "Add";
    this.counterId ='';
    this.setState({ modalAddEdit: true }); 
    this.setState({name: ''});
    this.setState({date: today });
    this.setState({hours: ''});
    this.setState({isSocialDistancing: 'true'});
    this.setState({__v: ''})
    this.setState({record: this.state});
  }

  handleEdit = (id)=>{
    this.action = "Edit"; 
    this.counterId = id;
    this.setState({ modalAddEdit: true });
    this.record = this.state.counters.filter(c => c._id === id);
    this.setState({name: this.record[0].name});
    this.setState({date: this.formatDate(this.record[0].date)});
    this.setState({hours: this.record[0].hours}); 
    this.setState({isSocialDistancing: this.record[0].isSocialDistancing});
    this.setState({__v: '0'})
    this.setState({record:[]})
  }

  handleCancell=()=>{
    this.setState({ modalAddEdit: false });
    axios.get(apiUrl + 'social-interactions')
    .then(res => {     
     this.setState({counters: res.data}); 
    })
    return;
  }

  handleSubmit=()=>{
    this.setState({ modalAddEdit: false }); 
    if (this.action === "Edit") { // Update record
      if (this.state.isSocialDistancing === 'false' ||
        this.state.isSocialDistancing === '') {      
         this.setState({isSocialDistancing: "false"}); 
      }else{    
        this.setState({isSocialDistancing: "true"}); 
      }   
      if (this.state.date === null || this.state.date === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Date!',
          })  
           return;
      }
      let d = new Date(this.state.date);
      if (this.state.name === null || this.state.name === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Name!',
          })  
           return;
      }
      if (this.state.hours === null || this.state.hours === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Hours!',
          })  
           return;
      }
      let localDate = d.setHours(0, -d.getTimezoneOffset(), 0, 0); //removing the timezone offset.
      fetch(apiUrl + "social-interactions/" + this.counterId, {
        "method": "PUT",
        "headers": {
        "content-type": "application/json",
        "accept": "application/json"
        },
        "body": JSON.stringify({
            _id: this.counterId,
            name: this.state.name,
            date: localDate,
            hours: this.state.hours.toString(), 
            isSocialDistancing: this.state.isSocialDistancing
        })
      })
      .then(response => response.json())
      .then(response => {
          console.log(response)                
          this.props.history.push("/");       
          Swal.fire("Record updated!"); 
          this.props.history.push("/ListSocialInteraction");        
      })
      .catch(err => {
          console.log(err);
            Swal.fire({
          icon: 'error',
          title: 'Oops...',
            text: err.toString(),
          })  
          return;
      }); 
    } else{ 
        // Insert record
        // creates entity
        //"x-rapidapi-host": "fairestdb.p.rapidapi.com",
        //"x-rapidapi-key": "apikey", 
       let result = this.state.isSocialDistancing === "" ||
       this.state.isSocialDistancing === "false" ? "false":"true";
       if (this.state.date === null || this.state.date === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Date!',
          })  
           return;
      }
       let d = new Date(this.state.date);
       if (this.state.name === null || this.state.name === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Name!',
          })  
           return;
      }
      if (this.state.hours === null || this.state.hours === '' ) {
        Swal.fire({
              icon: 'error',
              title: 'Oops...',
               text: 'Enter Hours!',
          })  
           return;
      }
       let localDate = d.setHours(0, -d.getTimezoneOffset(), 0, 0); //removing the timezone offset.
       fetch(apiUrl + "social-interactions", {
        "method": "POST",
        "headers": {
        "content-type": "application/json",
        "accept": "application/json"
        },
        "body": JSON.stringify({
            name: this.state.name,
            date: localDate,
            hours: this.state.hours,  
            isSocialDistancing: result.toString()
        })
      })
      .then(response => response.json())
      .then(response => {
          console.log(response)
          this.props.history.push("/");        
          Swal.fire('Record added successfuly!');
          this.props.history.push("/ListSocialInteraction"); 
      })
      .catch(err => {
          console.log(err);
            Swal.fire({
          icon: 'error',
          title: 'Oops...',
            text: err.toString(),
          })  
          return;    
      });
    }          
    this.setState={counters: [], record:[],body:[],action:'',modalAddEdit: false,
      name: '',
      date: '',
      hours: 0,
      isSocialDistancing: "false",
      __v: '0'
      } 
      this.props.history.push("/ListSocialInteraction");  
    }


  formatDate(inputDate) {
    let dateFormat = inputDate.substring(0, 10).replace('-','/');
    let theReturn =new Date(dateFormat);
    const date = new Date(dateFormat);
    if (!isNaN(date.getTime())) {
        const year =  JSON.stringify(date.getFullYear());
        const month = date.getMonth() + 1;
        const day =   date.getDate();
        theReturn= ((month < 10 ? '0' + month : month) +  '/' + (day < 10 ? '0' + day : day) + "/" + year);
        } 
    return theReturn
  }

  handleClose=(e)=>{
    this.modalClose(e);
  }

  handleChangeChk2=e=>{  
    // eslint-disable-next-line eqeqeq
    let result = this.state.isSocialDistancing == 'false'
    // eslint-disable-next-line eqeqeq
    || this.state.isSocialDistancing == '' ? 'true':'false'  
    this.setState({ [e.target.name]: result })
    return result;       
  }

  render(){
    return(
      <React.Fragment>     
        <main className="container"> 
          <button type="button" 
            className="btn btn-primary float-right m-2"
            data-toggle="modal" 
            data-target="#modalEAdddit"  
            onClick={this.handleAdd}
            data-backdrop="static" 
            data-keyboard="false">Add Social Interaction
          </button>
          <div>
             <h3>Social Interaction List</h3>
          </div>
          <br/>
          <div style={{ background: '#CC99FF' }}>
            <div className="ml-2">
              <input type="checkbox"
              value={this.state.wasFiltered}
              onChange={this.handleChangeChk}
              className="mr-2" />Diplay records within last 14 days
            </div>
            <br/>
          </div>
          
          <table style={{width: 1000}}>
            <TableHead>
                <SIVisitedTableHeader/>
            </TableHead>  
            <TableBody> 
              <SICounters
                counters={this.state.counters}
                onDelete={this.handleDelete}
                onEdit={this.handleEdit}         
              />   
            </TableBody>           
          </table>
          <Modal show={this.state.modalAddEdit} >
          <div  className="modal-body">
          <br/>         
          <h2 className="mr-2">{this.action}</h2>
          <form onSubmit={this.onSubmit} >
              <div className="form-group">      
                  <label>Name</label>
                  <input type="text" 
                    className="form-control"
                    placeholder="Name"
                    value={this.state.name}
                    required
                    onChange={(e) => this.setState({ name: e.target.value })}
                    id="name"/>
              </div>
              <br/>
              <div className="form-group"> 
                <label>Date (mm/dd/yyyy): </label>
                <input
                  type="text"
                  name="date"
                  value={this.state.date}
                  onChange={this.onHandleDateChange }
                  />               
              </div>
              <br/>
              <div className="form-group">     
              <label>Hours: </label>
                <input
                  type="text"
                  name="hours"
                  value={this.state.hours}
                  onChange={this.onHandleNumberChange }
                  />                        
              </div>  
              <br/>    
              <div className="form-group mr-2">                    
                <div className="mr-2">
                  <input type="checkbox" 
                  name="isSocialDistancing"  
                  defaultChecked={this.state.isSocialDistancing} 
                  value={this.state.isSocialDistancing}
                  onChange={this.handleChangeChk2}
                  className="mr-2"/>
                    Is practice Social Distancing?
                </div>
              </div>                                            
               <br></br>    
              <div className="form-group">
                  <span className="mr-2">
                    <input type="button"  onClick={this.handleSubmit} value="Save" className="btn btn-primary" />
                  </span>
                  <span  className="mr-2">
                  <button  className="btn btn-primary" onClick={this.handleCancell}>Cancel</button>          
                  </span>
              </div> 
              <br/>              
          </form>  
          </div>  
        </Modal>   
        </main>
      </React.Fragment>
    )
  }
}
export default ListSocialInteraction;
