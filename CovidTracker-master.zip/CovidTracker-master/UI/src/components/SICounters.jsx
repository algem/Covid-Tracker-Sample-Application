import React, { Component } from 'react';
import SICounter from './SICounter'
class SICounters extends Component { 
    render() { 
       const {counters,onDelete,onEdit} = this.props
        return (
            <>            
                {counters.map(counter => (                  
                    <SICounter                     
                        key={counter._id} 
                        counter={counter}
                        onEdit={onEdit}
                        onDelete={onDelete} 
                    />                         
                ))}           
            </>
        );
    }
}
export default SICounters ;