import React, { Component } from 'react';

let  vMessage1 = "You have bee exposed to a crowded place for the last 14 days..\r\nTry to avoid crowded places to minimised your exposure risk."
let namesSplit1 = vMessage1.split(/\r?\n/);
//let  vMessage2 = "Thank you for helping to stop spread the virus by staying home "
//let namesSplit2 = vMessage2.split(/\r?\n/);

class NotificationSystem extends Component { 
    render() {
        return (
            <>
               {namesSplit1}
            </>
           
        )
    }
}
export default NotificationSystem 