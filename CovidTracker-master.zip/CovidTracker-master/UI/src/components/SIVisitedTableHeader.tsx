import React from "react";
import {TableRow,TableCell} from "@material-ui/core";

function SIVisitedTableHeader(): JSX.Element {
    return (
    <TableRow style={{ background: '#f2e6ff' }}>
      <TableCell >Name</TableCell>
      <TableCell >Date</TableCell>
      <TableCell >Hours</TableCell>
      <TableCell >Is Practicing SD</TableCell>
      <TableCell ></TableCell>
      <TableCell ></TableCell>
    </TableRow>      
  );
}
export default SIVisitedTableHeader;


