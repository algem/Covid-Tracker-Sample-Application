import React, { Component } from 'react';
import Counter from './counter'
class Counters extends Component {  
    render() { 
       const {counters,onDelete,onEdit} = this.props
        return (
            <>  
                {counters.map(counter => (
                    <Counter                     
                        key={counter._id} 
                        counter={counter}
                        onEdit={onEdit}
                        onDelete={onDelete} 
                    />                
                ))}           
           </>
        );
    }
}
export default Counters ;