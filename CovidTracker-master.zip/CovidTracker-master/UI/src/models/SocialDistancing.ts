export default class SocialDistancing{  
    _id:string;
    isSocialDistancing:string;
    name:string;
    date:string;
    hours: string;
    __v: string;
   
    constructor(item: any) {
      this._id= item._id;
      this.isSocialDistancing= item.isSocialDistancing;
      this.name = item.name;
      this.date = item.date;
      this.hours = item.hours;
      this.__v = '1.0.0';      
    }
  }

 //{"isSocialDistancing":false,"_id":"5ef8072eb6cb232080310b9c","name":"Joe","date":"2020-06-27T16:00:00.000Z","hours":1,"__v":0
    