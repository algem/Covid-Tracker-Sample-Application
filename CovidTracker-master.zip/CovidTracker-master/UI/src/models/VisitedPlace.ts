
export default class VisitedPLace {  
  _id:string;
  isCrowded:string;
  place:string;
  date:string;
  hours: string;
  __v: string;
 
  constructor(item: any) {
    this._id= item._id;
    this.isCrowded= item.isCrowded;
    this.place = item.place;
    this.date = item.date;
    this.hours = item.hours;
    this.__v = '1.0.0';      
  }
}
