# CovidTracker

Notes:

- In order to use .rest file, install the Rest Client extension on Visual Studio Code
- This project is using concurrently to run both server and client. Run "npm run dev" to start-up both api project and client project
