npm install
npm install cors
npm install express --save
npm install express-validator
npm install mongoose